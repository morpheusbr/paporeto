<?php
require_once (ROOT_INC.'topo.inc.php');
$html.='<div class="menu">Erro Desconhecido.</div>';
$html.='O sistema se comportou de modo inesperado!';
require_once (ROOT_INC.'rodape.inc.php');