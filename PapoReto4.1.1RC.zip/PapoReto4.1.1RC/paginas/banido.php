<?php
require_once (ROOT_INC.'topo.inc.php');
$html.='<div class="menu">Banido.</div>';
$html.='<img src="'.$imagecache->cache(URL_IMAGENS.'atencao.png').'">Você está banido de nosso site!';
require_once (ROOT_INC.'rodape.inc.php');