<?php
/**
 * @author Fabio Vieira
 * @copyright 2017
 */
header('Location: '.$_SERVER['REQUEST_SCHEME'].'://' . $_SERVER['HTTP_HOST'].'/');
exit;
?>